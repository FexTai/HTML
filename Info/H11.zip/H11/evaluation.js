let x = Number(document.getElementById("var1").value) + Number(document.getElementById("var2").value);

function addieren() {
    alert(
        Number(document.getElementById("var1").value) + 
        Number(document.getElementById("var2").value));
} 

function subtrahieren() {
    alert(
        Number(document.getElementById("var1").value) - 
        Number(document.getElementById("var2").value));
} 

function dividieren() {
    alert(
        Number(document.getElementById("var1").value) / 
        Number(document.getElementById("var2").value));
} 

function multiplizieren() {
    alert(
        Number(document.getElementById("var1").value) * 
        Number(document.getElementById("var2").value));
} 