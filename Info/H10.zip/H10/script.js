let x = Math.floor(Math.random()* 100);
let y = Math.floor(Math.random()* 100);

document.getElementById("p").innerHTML = x + " + " + y + " = " + (x+y);

function showDate() {
    alert(new Date());
}
